
<?php
include_once "conexao.php";
include_once "funcoes.php";

if (isset($_GET['acao']) && $_GET['acao']== 'deletar') {
    dd("ESTOU QUERENDO DELETAR ALGUEM NO BANCO DE DADOS");

    $id = $_GET['id'];

    $conexaoComBanco = abrirBanco();
    $sql = "DELETE FROM pessoas where id = $id";

    if($conexaoComBanco->query($sql)=== TRUE) {
        echo "Usuário cadastrado com sucesso";
    }else{
        echo " Erro ao excluir contato: ". $conexaoComBanco->error;
    }
    fecharBanco($conexaoComBanco);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de pessoas</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <header>
        <h1>Agenda de Contatos</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="cadastrar.php">Cadastrar</a></li>
            </ul>
        </nav>
    </header>
    <section>
        <h2>Lista de contatos</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Sobrenome</th>
                    <th>Nascimento</th>
                    <th>Endereço</th>
                    <th>Telefone</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $conexaoComBanco = abrirBanco();

                $sql = "SELECT * FROM pessoas";

                $result = $conexaoComBanco->query($sql);

                if ($result->num_rows > 0){
                    while($registro = $result->fetch_assoc()) {
                        ?>

                        <tr>
                            <td><?= $registro['id']?></td>
                        
                            <td><?= $registro['nome']?></td>
                       
                            <td><?= $registro['sobrenome']?></td>
                        
                            <td><?= $registro['nascimento']?></td>
                        
                            <td><?= $registro['endereco']?></td>
                        
                            <td><?= $registro['telefone']?></td>

                            <td>
                                <a href="aditar.php?id=<?= $"><button>Editar</button></a>
                                <a href="?acao=deletarI&id="><?= $registros['id'] ?>
                                onclick="return confirm('Tem certeza que deseja apagar?')"><button>Excluir</button></a>
                                
                            </td>
                        </tr>

                        <?php
                    }

                    }

                }else{
                    echo (" <tr><td colspan='6'> Nenhum registro encontrado<td><tr> ");
                }

                ?>


                <tr>
                    <td>1</td>
                    <td>Dabura</td>
                    <td>majin</td>
                    <td>15/02/156</td>
                    <td>floresta infernal</td>
                    <td>(65)99999-2222</td>
                </tr>
            </tbody>
        </table>
    </section>

</body>
</html>
<!-- php -S localhost:8080 -->